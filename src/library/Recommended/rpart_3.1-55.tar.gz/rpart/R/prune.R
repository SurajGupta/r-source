prune <- function(tree, ...)  UseMethod("prune")
