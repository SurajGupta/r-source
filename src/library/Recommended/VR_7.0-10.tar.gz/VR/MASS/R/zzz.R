.First.lib <- function(lib, pkg) {
  library.dynam("MASS", pkg, lib)
}
