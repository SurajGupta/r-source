## no S4 methodology here; speedup :
.noGenerics <- TRUE
