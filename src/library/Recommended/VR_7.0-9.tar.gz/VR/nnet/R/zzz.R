.First.lib <- function(lib, pkg)
{
    library.dynam("nnet", pkg, lib)
    require(MASS)
}
