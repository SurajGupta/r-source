.First.lib <- function(lib, pkg) library.dynam("class", pkg, lib)
