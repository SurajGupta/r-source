Run 
	R --vanilla <Rtest >Rtest.out
	diff Rtest.out Rtest.out.save

to check all the examples.
