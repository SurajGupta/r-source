## Ensure consistent "diss.." class --- make "namespace-private-global !
..dClass <- c("dissimilarity", "dist")
