

as.data.frame.difftime <-as.data.frame.vector


